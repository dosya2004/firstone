﻿import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

df = pd.read_csv("Price Predictor.csv")
print(df)

try:
    df = pd.read_csv("housing.csv")
    print(df.head())
except Exception as e:
    print("Ошибка при чтении файла:", e)


try:
    X = df[["area", "bedrooms", "age"]]
    y = df["price"]
except Exception as e:
    print("Ошибка при подготовке данных:", e)


try:
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
except Exception as e:
    print("Ошибка при разделении данных:", e)


try:
    model = LinearRegression()
    model.fit(X_train, y_train)
except Exception as e:
    print("Ошибка при обучении модели:", e)


try:
    y_pred = model.predict(X_test)

    
    plt.scatter(y_test, y_pred)
    plt.xlabel("Фактическая цена")
    plt.ylabel("Предсказанная цена")
    plt.title("Сравнение фактической и предсказанной цены")

    
except Exception as e:
    print("Ошибка при визуализации или предсказании:", e)
