﻿namespace Double3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            InputTextBox1 = new TextBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            OnDecimalButtonClick = new Button();
            button18 = new Button();
            SuspendLayout();
            // 
            // InputTextBox1
            // 
            InputTextBox1.Location = new Point(12, 12);
            InputTextBox1.Multiline = true;
            InputTextBox1.Name = "InputTextBox1";
            InputTextBox1.Size = new Size(406, 81);
            InputTextBox1.TabIndex = 0;
            // 
            // button1
            // 
            button1.BackColor = Color.Transparent;
            button1.Font = new Font("Tahoma", 10F, FontStyle.Bold);
            button1.Location = new Point(12, 110);
            button1.Name = "button1";
            button1.Size = new Size(200, 94);
            button1.TabIndex = 1;
            button1.Text = "CE";
            button1.UseVisualStyleBackColor = false;
            button1.Click += OnClearButtonClick;
            // 
            // button2
            // 
            button2.Font = new Font("Tahoma", 10F, FontStyle.Bold);
            button2.Location = new Point(218, 110);
            button2.Name = "button2";
            button2.Size = new Size(97, 94);
            button2.TabIndex = 2;
            button2.Text = "%";
            button2.UseVisualStyleBackColor = true;
            button2.Click += OnPercentageButtonClick;
            // 
            // button3
            // 
            button3.BackColor = Color.DarkOrange;
            button3.Font = new Font("Tahoma", 10F, FontStyle.Bold);
            button3.Location = new Point(321, 110);
            button3.Name = "button3";
            button3.Size = new Size(97, 94);
            button3.TabIndex = 3;
            button3.Text = "/";
            button3.UseVisualStyleBackColor = false;
            button3.Click += OnOperationButtonClick;
            // 
            // button4
            // 
            button4.Font = new Font("Tahoma", 10F, FontStyle.Bold);
            button4.Location = new Point(12, 210);
            button4.Name = "button4";
            button4.Size = new Size(97, 94);
            button4.TabIndex = 4;
            button4.Text = "7";
            button4.UseVisualStyleBackColor = true;
            button4.Click += OnNumberButtonClick;
            // 
            // button5
            // 
            button5.Font = new Font("Tahoma", 10F, FontStyle.Bold);
            button5.Location = new Point(115, 210);
            button5.Name = "button5";
            button5.Size = new Size(97, 94);
            button5.TabIndex = 5;
            button5.Text = "8";
            button5.UseVisualStyleBackColor = true;
            button5.Click += OnNumberButtonClick;
            // 
            // button6
            // 
            button6.Font = new Font("Tahoma", 10F, FontStyle.Bold);
            button6.Location = new Point(218, 210);
            button6.Name = "button6";
            button6.Size = new Size(97, 94);
            button6.TabIndex = 6;
            button6.Text = "9";
            button6.UseVisualStyleBackColor = true;
            button6.Click += OnNumberButtonClick;
            // 
            // button7
            // 
            button7.BackColor = Color.DarkOrange;
            button7.Font = new Font("Tahoma", 10F, FontStyle.Bold);
            button7.Location = new Point(321, 210);
            button7.Name = "button7";
            button7.Size = new Size(97, 94);
            button7.TabIndex = 7;
            button7.Text = "*";
            button7.UseVisualStyleBackColor = false;
            button7.Click += OnOperationButtonClick;
            // 
            // button8
            // 
            button8.BackColor = Color.DarkOrange;
            button8.Font = new Font("Tahoma", 10F, FontStyle.Bold);
            button8.Location = new Point(321, 310);
            button8.Name = "button8";
            button8.Size = new Size(97, 94);
            button8.TabIndex = 11;
            button8.Text = "-";
            button8.UseVisualStyleBackColor = false;
            button8.Click += OnOperationButtonClick;
            // 
            // button9
            // 
            button9.Font = new Font("Tahoma", 10F, FontStyle.Bold);
            button9.Location = new Point(218, 310);
            button9.Name = "button9";
            button9.Size = new Size(97, 94);
            button9.TabIndex = 10;
            button9.Text = "6";
            button9.UseVisualStyleBackColor = true;
            button9.Click += OnNumberButtonClick;
            // 
            // button10
            // 
            button10.Font = new Font("Tahoma", 10F, FontStyle.Bold);
            button10.Location = new Point(115, 310);
            button10.Name = "button10";
            button10.Size = new Size(97, 94);
            button10.TabIndex = 9;
            button10.Text = "5";
            button10.UseVisualStyleBackColor = true;
            button10.Click += OnNumberButtonClick;
            // 
            // button11
            // 
            button11.Font = new Font("Tahoma", 10F, FontStyle.Bold);
            button11.Location = new Point(12, 310);
            button11.Name = "button11";
            button11.Size = new Size(97, 94);
            button11.TabIndex = 8;
            button11.Text = "4";
            button11.UseVisualStyleBackColor = true;
            button11.Click += OnNumberButtonClick;
            // 
            // button12
            // 
            button12.BackColor = Color.DarkOrange;
            button12.Font = new Font("Tahoma", 10F, FontStyle.Bold);
            button12.Location = new Point(321, 410);
            button12.Name = "button12";
            button12.Size = new Size(97, 94);
            button12.TabIndex = 15;
            button12.Text = "+";
            button12.UseVisualStyleBackColor = false;
            button12.Click += OnOperationButtonClick;
            // 
            // button13
            // 
            button13.Font = new Font("Tahoma", 10F, FontStyle.Bold);
            button13.Location = new Point(218, 410);
            button13.Name = "button13";
            button13.Size = new Size(97, 94);
            button13.TabIndex = 14;
            button13.Text = "3";
            button13.UseVisualStyleBackColor = true;
            button13.Click += OnNumberButtonClick;
            // 
            // button14
            // 
            button14.Font = new Font("Tahoma", 10F, FontStyle.Bold);
            button14.Location = new Point(115, 410);
            button14.Name = "button14";
            button14.Size = new Size(97, 94);
            button14.TabIndex = 13;
            button14.Text = "2";
            button14.UseVisualStyleBackColor = true;
            button14.Click += OnNumberButtonClick;
            // 
            // button15
            // 
            button15.Font = new Font("Tahoma", 10F, FontStyle.Bold);
            button15.Location = new Point(12, 410);
            button15.Name = "button15";
            button15.Size = new Size(97, 94);
            button15.TabIndex = 12;
            button15.Text = "1";
            button15.UseVisualStyleBackColor = true;
            button15.Click += OnNumberButtonClick;
            // 
            // button16
            // 
            button16.BackColor = Color.DarkOrange;
            button16.Font = new Font("Tahoma", 10F, FontStyle.Bold);
            button16.Location = new Point(321, 510);
            button16.Name = "button16";
            button16.Size = new Size(97, 94);
            button16.TabIndex = 19;
            button16.Text = "=";
            button16.UseVisualStyleBackColor = false;
            button16.Click += OnEqualsButtonClick;
            // 
            // OnDecimalButtonClick
            // 
            OnDecimalButtonClick.Font = new Font("Tahoma", 10F, FontStyle.Bold);
            OnDecimalButtonClick.Location = new Point(218, 510);
            OnDecimalButtonClick.Name = "OnDecimalButtonClick";
            OnDecimalButtonClick.Size = new Size(97, 94);
            OnDecimalButtonClick.TabIndex = 18;
            OnDecimalButtonClick.Text = ".";
            OnDecimalButtonClick.UseVisualStyleBackColor = true;
            OnDecimalButtonClick.Click += OnDecimalButtonClick_Click;
            // 
            // button18
            // 
            button18.Font = new Font("Tahoma", 10F, FontStyle.Bold);
            button18.Location = new Point(12, 510);
            button18.Name = "button18";
            button18.Size = new Size(200, 94);
            button18.TabIndex = 17;
            button18.Text = "0";
            button18.UseVisualStyleBackColor = true;
            button18.Click += OnNumberButtonClick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(432, 622);
            Controls.Add(button16);
            Controls.Add(OnDecimalButtonClick);
            Controls.Add(button18);
            Controls.Add(button12);
            Controls.Add(button13);
            Controls.Add(button14);
            Controls.Add(button15);
            Controls.Add(button8);
            Controls.Add(button9);
            Controls.Add(button10);
            Controls.Add(button11);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(InputTextBox1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox InputTextBox1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button OnDecimalButtonClick;
        private Button button18;
    }
}
