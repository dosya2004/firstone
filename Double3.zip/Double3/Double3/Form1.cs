namespace Double3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void OnNumberButtonClick(object sender, EventArgs e) // responsible for all numbers
        {
            var button = sender as Button;
            if (button != null)
            {
                InputTextBox1.Text += button.Text;
            }
        }

        private void OnOperationButtonClick(object sender, EventArgs e) // responsible for all operators
        {
            var button = sender as Button;
            if (button != null)
            {
                InputTextBox1.Text += $" {button.Text} ";
            }
        }

        private void OnDecimalButtonClick_Click(object sender, EventArgs e) // takes care of decimals
        {
            if (!InputTextBox1.Text.EndsWith("."))
            {
                InputTextBox1.Text += ".";
            }
        }

        private void OnPercentageButtonClick(object sender, EventArgs e) // calculates percents
        {
            try
            {
                var currentText = InputTextBox1.Text;
                if (double.TryParse(currentText, out double value))
                {
                    var percentage = value / 100.0;
                    InputTextBox1.Text = percentage.ToString();
                }
                else
                {
                    MessageBox.Show("Invalid input for percentage calculation.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Calculation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void OnClearButtonClick(object sender, EventArgs e) // deletes all
        {
            InputTextBox1.Clear();
        }

        private void OnEqualsButtonClick(object sender, EventArgs e) // gives the answer
        {
            try
            {
                var result = CalculatorService.Calculate(InputTextBox1.Text);

                // Format the result to 2 decimal places
                InputTextBox1.Text = result.ToString("F2");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Calculation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
    public static class CalculatorService
    {
        public static double Calculate(string input)
        {
            var data = input.Split(' ');

            // we have the correct input format
            if (data.Length != 3) throw new InvalidOperationException("Invalid input format");

            // parse numbers using culture-invariant parsing
            var leftOperand = double.Parse(data[0], System.Globalization.CultureInfo.InvariantCulture);
            var operation = data[1];
            var rightOperand = double.Parse(data[2], System.Globalization.CultureInfo.InvariantCulture);

            return operation switch
            {
                "+" => leftOperand + rightOperand,
                "-" => leftOperand - rightOperand,
                "*" => leftOperand * rightOperand,
                "/" => rightOperand != 0 ? leftOperand / rightOperand : throw new DivideByZeroException(),
                _ => throw new InvalidOperationException("Unsupported operation")
            };
        }
    }
}
