using Microsoft.VisualStudio.TestTools.UnitTesting;
using Double3; 
using System;

namespace Double3.Tests
{
    [TestClass]
    public class CalculatorServiceTests
    {
        [TestMethod]
        public void Calculate_Addition_ReturnsCorrectResult()
        {
            // Arrange
            var input = "5 + 3";

            // Act
            var result = CalculatorService.Calculate(input);

            // Assert
            Assert.AreEqual(8.0, result);
        }

        [TestMethod]
        public void Calculate_DivisionByZero_ThrowsException()
        {
            // Arrange
            var input = "8 / 0";

            // Act & Assert
            var exception = Assert.ThrowsException<DivideByZeroException>(() => CalculatorService.Calculate(input));
            Assert.AreEqual("Attempted to divide by zero.", exception.Message);
        }

        // Additional tests go here...
    }
}
